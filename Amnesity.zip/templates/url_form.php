
<style type="text/css">

html body {
	margin-top: 50px !important;
}

#top_form {
	position: fixed;
	top:0;
	left:0;
	width: 100%;
	
	margin:0;
	
	z-index: 2100000000;
	-moz-user-select: none; 
	-khtml-user-select: none; 
	-webkit-user-select: none; 
	-o-user-select: none; 
	
	border-bottom:1px solid #151515;
	
    background:#8fb5f2;
    opacity: 0.5;
	
	height:34px;
	line-height:25px;
}

#top_form input[name=url] {
	text-align: center;
	position: fixed;
	right: 15%;
	top: 5px;
	width: 560px;
	height: 20px;
	padding: 6px;
	font: 15px "Helvetica Neue",Helvetica,Arial,sans-serif;
	border: 0px none;
	opacity: 1;
	background: none repeat scroll 0% 0% #FFF;
}

#close_search {
    color: white;
    font-size: 15px;
    border: 3px;
    background-color: lightgrey;
    position: fixed;
	right: .5%;
	top: 5px;
	z-index: 2100000001;
    opacity: .8;
}

#open_search {
    color: white;
    font-size: 15px;
    border: 3px;
    background-color: lightgrey;
    position: fixed;
	right: .5%;
	top: 5px;
	z-index: 2100000001;
    opacitY: .8;
    display: none;
}

</style>

<script>
var url_text_selected = false;

function smart_select(ele){

	ele.onblur = function(){
		url_text_selected = false;
	};
	
	ele.onclick = function(){
		if(url_text_selected == false){
			this.focus();
			this.select();
			url_text_selected = true;
		}
	};
}
</script>

<div id="close_search">

<p1 class="closesearchbar"
onclick="Close(); CloseClose(); OpenOpen()">Close Search Bar</p1>

</div>

<div id="open_search">
    
<p2 class="opensearchbar"
onclick="Open(); CloseOpen(); OpenClose()">Open Search Bar</p2>

</div>

<div id="top_form">

	<div style="width:800px; margin:0 auto;">
	
		<form method="post" action="index.php" target="_top" style="position:fixed; top: 1.5px; font-size: 12px; margin:0; padding:0;">
			<input type="button" value="Home" onclick="window.location.href='index.php'">
			<input style="position: fixed; top: 3.5px; height: 10px;" type="text" name="url" value="<?php echo $url; ?>" autocomplete="off">
			<input type="hidden" name="form" value="1">
			<input type="submit" value="Go">
		</form>
		
	</div>
	
</div>

<script type="text/javascript">
    function Close() {
        document.getElementById("top_form").style.display = "none";
    }
    function CloseClose() {
        document.getElementById('close_search').style.display = "none";
    }
    function OpenOpen() {
        document.getElementById('open_search').style.display = "block";
    }
    function Open() {
        document.getElementById("top_form").style.display = "block";
    }
    function CloseOpen() {
        document.getElementById('open_search').style.display = "none";
    }
    function OpenClose() {
        document.getElementById("close_search").style.display = "block"; 
    }
	smart_select(document.getElementsByName("url")[0]);
</script>
